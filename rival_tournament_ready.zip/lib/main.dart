import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:uuid/uuid.dart';

void main() {
  runApp(RivalTournamentApp());
}

class RivalTournamentApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Rival Tournament',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: TournamentHomePage(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class Tournament {
  final String id;
  final String name;
  final String game;
  final String date;
  final String details;
  final int seats;
  Tournament({
    required this.id,
    required this.name,
    required this.game,
    required this.date,
    required this.details,
    required this.seats,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'game': game,
        'date': date,
        'details': details,
        'seats': seats,
      };

  factory Tournament.fromJson(Map<String, dynamic> j) {
    return Tournament(
      id: j['id'],
      name: j['name'],
      game: j['game'],
      date: j['date'],
      details: j['details'],
      seats: j['seats'],
    );
  }
}

class TournamentHomePage extends StatefulWidget {
  @override
  _TournamentHomePageState createState() => _TournamentHomePageState();
}

class _TournamentHomePageState extends State<TournamentHomePage> {
  List<Tournament> _tournaments = [];
  bool _loading = true;
  final String _storageKey = 'rival_tournaments';
  final uuid = Uuid();

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final sp = await SharedPreferences.getInstance();
    final raw = sp.getString(_storageKey);
    if (raw != null) {
      final list = jsonDecode(raw) as List;
      _tournaments = list.map((e) => Tournament.fromJson(e)).toList();
    } else {
      // Seed one default tournament (Free Fire)
      final demo = Tournament(
        id: uuid.v4(),
        name: 'Rival Free Fire Cup',
        game: 'Free Fire',
        date: '2025-12-10',
        details: 'Free entry. Solo/duo squads. Prize TBD.',
        seats: 100,
      );
      _tournaments = [demo];
      await sp.setString(_storageKey, jsonEncode(_tournaments.map((e) => e.toJson()).toList()));
    }
    setState(() => _loading = false);
  }

  Future<void> _save() async {
    final sp = await SharedPreferences.getInstance();
    await sp.setString(_storageKey, jsonEncode(_tournaments.map((e) => e.toJson()).toList()));
  }

  void _createTournament() async {
    final result = await Navigator.push(context, MaterialPageRoute(builder: (_) => CreateTournamentPage()));
    if (result is Tournament) {
      setState(() => _tournaments.add(result));
      await _save();
    }
  }

  void _joinTournament(Tournament t) async {
    // Simple join flow: confirm and reduce seats
    if (t.seats <= 0) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('No seats left')));
      return;
    }
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: Text('Join ${t.name}?'),
        content: Text('Join this tournament (${t.game}) on ${t.date}?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: Text('Cancel')),
          TextButton(onPressed: () => Navigator.pop(context, true), child: Text('Join')),
        ],
      ),
    );
    if (ok == true) {
      setState(() {
        final idx = _tournaments.indexWhere((x) => x.id == t.id);
        if (idx != -1) {
          _tournaments[idx] = Tournament(
            id: t.id,
            name: t.name,
            game: t.game,
            date: t.date,
            details: t.details,
            seats: t.seats - 1,
          );
        }
      });
      await _save();
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Joined successfully!')));
    }
  }

  void _adminPanel() {
    Navigator.push(context, MaterialPageRoute(builder: (_) => AdminPage(tournaments: _tournaments, onUpdate: (list) async {
      setState(() => _tournaments = list);
      await _save();
    })));
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) return Scaffold(body: Center(child: CircularProgressIndicator()));
    return Scaffold(
      appBar: AppBar(
        title: Text('Rival Tournament'),
        actions: [
          IconButton(onPressed: _adminPanel, icon: Icon(Icons.admin_panel_settings)),
        ],
      ),
      body: _tournaments.isEmpty
          ? Center(child: Text('No tournaments yet. Create one!'))
          : ListView.builder(
              itemCount: _tournaments.length,
              itemBuilder: (_, i) {
                final t = _tournaments[i];
                return Card(
                  margin: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                  child: ListTile(
                    title: Text(t.name),
                    subtitle: Text('${t.game} • ${t.date}\nSeats left: ${t.seats}'),
                    isThreeLine: true,
                    trailing: ElevatedButton(onPressed: () => _joinTournament(t), child: Text('Join')),
                  ),
                );
              },
            ),
      floatingActionButton: FloatingActionButton(
        onPressed: _createTournament,
        child: Icon(Icons.add),
        tooltip: 'Create Tournament',
      ),
      bottomNavigationBar: Container(
        padding: EdgeInsets.all(12),
        child: Text('Instagram: @rivaltournament07', textAlign: TextAlign.center),
      ),
    );
  }
}

class CreateTournamentPage extends StatefulWidget {
  @override
  _CreateTournamentPageState createState() => _CreateTournamentPageState();
}

class _CreateTournamentPageState extends State<CreateTournamentPage> {
  final _formKey = GlobalKey<FormState>();
  final _name = TextEditingController();
  final _game = TextEditingController(text: 'Free Fire');
  final _date = TextEditingController();
  final _details = TextEditingController();
  final _seats = TextEditingController(text: '100');
  final uuid = Uuid();

  @override
  void dispose() {
    _name.dispose();
    _game.dispose();
    _date.dispose();
    _details.dispose();
    _seats.dispose();
    super.dispose();
  }

  void _submit() {
    if (!_formKey.currentState!.validate()) return;
    final t = Tournament(
      id: uuid.v4(),
      name: _name.text.trim(),
      game: _game.text.trim(),
      date: _date.text.trim(),
      details: _details.text.trim(),
      seats: int.tryParse(_seats.text.trim()) ?? 100,
    );
    Navigator.pop(context, t);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Create Tournament')),
      body: Padding(
        padding: EdgeInsets.all(12),
        child: Form(
          key: _formKey,
          child: ListView(
            children: [
              TextFormField(controller: _name, decoration: InputDecoration(labelText: 'Tournament name'), validator: (v) => v == null || v.isEmpty ? 'Enter name' : null),
              SizedBox(height: 8),
              TextFormField(controller: _game, decoration: InputDecoration(labelText: 'Game')),
              SizedBox(height: 8),
              TextFormField(controller: _date, decoration: InputDecoration(labelText: 'Date (YYYY-MM-DD)')),
              SizedBox(height: 8),
              TextFormField(controller: _details, decoration: InputDecoration(labelText: 'Details'), maxLines: 3),
              SizedBox(height: 8),
              TextFormField(controller: _seats, decoration: InputDecoration(labelText: 'Seats'), keyboardType: TextInputType.number),
              SizedBox(height: 16),
              ElevatedButton(onPressed: _submit, child: Text('Create')),
            ],
          ),
        ),
      ),
    );
  }
}

class AdminPage extends StatefulWidget {
  final List<Tournament> tournaments;
  final Function(List<Tournament>) onUpdate;
  AdminPage({required this.tournaments, required this.onUpdate});
  @override
  _AdminPageState createState() => _AdminPageState();
}

class _AdminPageState extends State<AdminPage> {
  late List<Tournament> _local;
  @override
  void initState() {
    super.initState();
    _local = widget.tournaments.map((e) => e).toList();
  }

  void _deleteTournament(String id) {
    setState(() => _local.removeWhere((t) => t.id == id));
  }

  void _saveAndExit() {
    widget.onUpdate(_local);
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Admin Panel'),
        actions: [TextButton(onPressed: _saveAndExit, child: Text('Save', style: TextStyle(color: Colors.white)))],
      ),
      body: ListView.builder(
        itemCount: _local.length,
        itemBuilder: (_, i) {
          final t = _local[i];
          return ListTile(
            title: Text(t.name),
            subtitle: Text('${t.game} • ${t.date} • Seats: ${t.seats}'),
            trailing: IconButton(icon: Icon(Icons.delete), onPressed: () => _deleteTournament(t.id)),
          );
        },
      ),
    );
  }
}
