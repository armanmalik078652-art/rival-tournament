# Rival Tournament (Ready-to-build)

This ZIP contains a Flutter prototype for a Free Fire tournament app (Rival Tournament).

## What I prepared for you
- A complete Flutter project skeleton (`pubspec.yaml` + `lib/main.dart`).
- A GitHub Actions workflow (`.github/workflows/flutter_build.yml`) that builds a release APK whenever you push to the `main` branch or trigger the workflow manually.
- A README with steps to get the APK from GitHub Actions.

## How you (or I) can get an APK without coding:
**Option A — Use GitHub (recommended, no local setup required except a GitHub account)**
1. Create a new GitHub repository (e.g., `rival_tournament`) on GitHub.
2. Upload all files from this ZIP (upload via website or push via git).
3. Ensure repository default branch is `main`.
4. Go to the "Actions" tab on GitHub — the `Build Flutter APK` workflow will run automatically on push. If not, trigger it with "Run workflow".
5. When the workflow finishes, open the workflow run and download the artifact named `app-release-apk` — that file is your `app-release.apk`.

**Option B — Build locally (if you can install Flutter)**
1. Install Flutter: https://flutter.dev/docs/get-started/install
2. Unzip this project, open a terminal inside the project's folder.
3. Run:
   - `flutter pub get`
   - `flutter build apk --release`
4. APK will be at `build/app/outputs/flutter-apk/app-release.apk`.

## Notes & limitations
- The APK produced by the workflow is an unsigned release APK built by Flutter on GitHub's runners. For Play Store, you must sign it with your own key.
- I cannot run builds or upload APKs for you from this chat environment, so I prepared this so you can get an APK without writing code. If you want, I can:
  - Help you push the files to GitHub step-by-step.
  - Walk you through downloading the workflow artifact.
  - Modify the app UI/text before you build — tell me exact changes and I'll update the files and repackage a new ZIP.

## Default settings in the app
- App name: Rival Tournament
- One seeded tournament: "Rival Free Fire Cup" on 2025-12-10
- Instagram link: @rivaltournament07

Good luck! Reply if you want me to:
- Change app name/text/colors and repackage the ZIP,
- Or I can guide you through pushing to GitHub and downloading the APK step-by-step.
